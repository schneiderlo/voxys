#!/usr/bin/env bash
set -euo pipefail
adventure_gtest=/home/modkin/.cache/bazel/_bazel_modkin/cbcbf4be6285ea63e5938aa06a96dc1e/external/googletest+/googletest
g++ -std=c++20 -O1 -Wall -Wextra -Werror -Isrc -I"$adventure_gtest/include" -I"$adventure_gtest" \
 src/game/adventure/item_catalog.cpp src/game/adventure/adventure_session.cpp src/game/adventure/adventure_save.cpp \
 src/game/adventure/building_catalog.cpp src/game/construction/construction_types.cpp src/game/expedition/save_generation.cpp \
 src/engine/platform/native/save_store.cpp src/engine/platform/native/save_worker.cpp src/engine/platform/native/native_adventure_saves.cpp \
 tests/test_native_adventure_saves.cpp "$adventure_gtest/src/gtest-all.cc" "$adventure_gtest/src/gtest_main.cc" \
 -pthread -o /tmp/voxys-adventure-session-tests
/tmp/voxys-adventure-session-tests --gtest_filter=NativeAdventureSavesTest.* --gtest_output=xml:build-adventure-g-a/authority-checks/native-storage-r04.xml
