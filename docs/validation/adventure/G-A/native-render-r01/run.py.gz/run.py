from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,re,signal,subprocess,time

root=Path.cwd();out=root/'build-adventure-g-a/native-render-smoke-r01'
storage=root/'build-adventure-g-a/native-worlds-r02'
world='bf7488a44a5e0be04c0ee231ac98288d'
binary=root/'build-native-save-host/bin/voxy_native'
def digest(data):return hashlib.sha256(data).hexdigest()
def files():return {str(p.relative_to(storage)):dict(bytes=p.stat().st_size,sha256=digest(p.read_bytes())) for p in storage.rglob('*') if p.is_file() and p.name not in ('lock','.lock')}
before=files();config=(root/'adventure.cfg').read_text().replace('show_stats = false','show_stats = true')
(out/'observed-adventure.cfg').write_text(config)
report=dict(status='running',startedUtc=datetime.now(timezone.utc).isoformat(),binarySha256=digest(binary.read_bytes()),world=world,storage=str(storage),filesBefore=before,observations=[],scope='Saved native world startup after render wiring fix; no gameplay input or save request, no screenshot; FPS log describes the running frame loop, not independent GPU draw-count proof')
env={k:v for k,v in os.environ.items() if not k.startswith('VOXY_ADVENTURE_')}
env.update(VOXY_WINDOW_BACKEND='x11',VOXY_ADVENTURE_ROOT=str(storage),VOXY_ADVENTURE_WORLD=world,VOXY_ADVENTURE_OBSERVE=str(out/'observation.json'))
command=[str(binary),'--config',str(out/'observed-adventure.cfg'),'--uncapped','--width','1280','--height','800','--log-level','debug']
report['command']=command;child=None;started=time.monotonic();forced=False
try:
    with (out/'process.log').open('w') as stream:
        child=subprocess.Popen(command,stdout=stream,stderr=subprocess.STDOUT,env=env)
        ready=None;last=None
        while time.monotonic()-started<70:
            if child.poll() is not None:raise RuntimeError('Native process exited before the observation window: '+str(child.returncode))
            try:state=json.loads((out/'observation.json').read_text())
            except (OSError,json.JSONDecodeError):time.sleep(.05);continue
            if state['observation']!=last:
                assert state['world']==world and state['parts']==19 and state['registeredBed']=='21' and state['hammerEquipped']
                assert [state[k] for k in ('wood','stone','scrap')]==[566,304,70]
                report['observations'].append(state);last=state['observation']
                if ready is None:ready=time.monotonic()
            if ready and time.monotonic()-ready>=8:break
            time.sleep(.05)
        assert len(report['observations'])>=20,'Too few fresh native observations'
        assert int(report['observations'][-1]['observation'])>int(report['observations'][0]['observation'])+20
        report['status']='passed'
except BaseException as error:
    report['status']='failed';report['error']=str(error)
finally:
    if child and child.poll() is None:
        child.send_signal(signal.SIGTERM)
        try:child.wait(timeout=15)
        except subprocess.TimeoutExpired:forced=True;child.kill();child.wait(timeout=5)
    report['exitCode']=child.returncode if child else None;report['forceKilled']=forced
    report['filesAfter']=files();report['savedDataUnchanged']=report['filesAfter']==before
    text=(out/'process.log').read_text(errors='replace')
    ansi=re.compile(r'\x1b\[[0-9;]*m');lines=[ansi.sub('',x) for x in text.splitlines()]
    report['fpsLines']=[x for x in lines if 'FPS:' in x]
    report['errors']=[x for x in lines if re.search(r'\[(?:ERROR|FATAL)\s*\]|uncaptured(?:\s+WebGPU)?(?:\s+GPU)?\s+error|WebGPU validation error',x,re.I)]
    report['elapsedSeconds']=round(time.monotonic()-started,3)
    if forced or report['exitCode']!=-signal.SIGTERM or report['errors'] or not report['savedDataUnchanged'] or not report['fpsLines']:report['status']='failed'
    (out/'summary.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:report[k] for k in ('status','elapsedSeconds','exitCode','forceKilled','savedDataUnchanged','fpsLines','errors')}))
raise SystemExit(0 if report['status']=='passed' else 1)
