import subprocess,json
from pathlib import Path
root=Path('/tmp/voxys-perf-followup');rows=[]
binaries={'original':'replication-probe','indexed':'replication-candidate','ranked':'replication-ranked'}
for layout in ['sparse','dense']:
 for repeat in range(5):
  order=['original','indexed','ranked']
  order=order[repeat%3:]+order[:repeat%3]
  for version in order:
   args=['/usr/bin/time','-v',str(root/binaries[version]),'65536','12','2000' if layout=='sparse' else '500',layout]
   p=subprocess.run(args,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
   name=f'replication-final-{layout}-{version}-{repeat}.log';(root/name).write_text(p.stdout)
   row={'bodies':65536,'layout':layout,'version':version,'repeat':repeat,'exit_code':p.returncode,'log':name,'summary':next((l for l in p.stdout.splitlines() if l.startswith('replication bodies')),None)}
   rows.append(row);(root/'replication-final.json').write_text(json.dumps(rows,indent=2));print(row,flush=True)
   if p.returncode:raise SystemExit(p.returncode)
