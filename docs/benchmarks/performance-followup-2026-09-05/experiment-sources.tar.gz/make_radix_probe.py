from pathlib import Path
p=Path('/tmp/voxys-perf-followup');s=Path('src/physics/gpu/deterministic_primitives.cpp').read_text()
s=s.replace('namespace voxy::physics {','namespace voxy::physics {\nextern WGPUQuerySet radixProfileQuerySet;',1)
a=s.index('    WGPUComputePassDescriptor passDesc{};',s.index('bool DeterministicGpuPrimitives::encodeRadixSortImpl('));b=s.index('    return flushParams(parameterBaseSlot, passCount);',a)
x=s[a:b]
x=x.replace('    WGPUComputePassDescriptor passDesc{};', '''    gpu::CompatPassTimestampWrites writes{};
    writes.querySet = radixProfileQuerySet;
    writes.beginningOfPassWriteIndex = 0;
    writes.endOfPassWriteIndex = 1;
    WGPUComputePassDescriptor passDesc{};
    if (radixProfileQuerySet) passDesc.timestampWrites = &writes;''',1)
x=x.replace('        const uint32_t dynamicOffset =', '''        if (radixProfileQuerySet && passIndex != 0) {
            wgpuComputePassEncoderEnd(compute);
            wgpuComputePassEncoderRelease(compute);
            writes.beginningOfPassWriteIndex = passIndex * 6;
            writes.endOfPassWriteIndex = passIndex * 6 + 1;
            compute = wgpuCommandEncoderBeginComputePass(encoder, &passDesc);
        }
        const uint32_t dynamicOffset =''',1)
for marker,stage in [('        wgpuComputePassEncoderSetPipeline(compute, radixPrefixPipeline_);',2),('            wgpuComputePassEncoderSetPipeline(compute, radixScatterPipeline_);',4)]:
 x=x.replace(marker,f'''        if (radixProfileQuerySet) {{
            wgpuComputePassEncoderEnd(compute);
            wgpuComputePassEncoderRelease(compute);
            writes.beginningOfPassWriteIndex = passIndex * 6 + {stage};
            writes.endOfPassWriteIndex = passIndex * 6 + {stage+1};
            compute = wgpuCommandEncoderBeginComputePass(encoder, &passDesc);
            wgpuComputePassEncoderSetBindGroup(compute, 0, bindGroups[passIndex], 1, &dynamicOffset);
        }}
'''+marker,1)
s=s[:a]+x+s[b:];(p/'primitives-observed.cpp').write_text(s)
