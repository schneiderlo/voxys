import os,subprocess,json,math
from pathlib import Path
root=Path('/tmp/voxys-perf-followup');shader=Path('shaders/physics_deterministic_primitives.wgsl').read_text();rows=[]
for digits in [4,8,16,32]:
 folder=root/f'tile-{digits}';(folder/'shaders').mkdir(parents=True,exist_ok=True)
 text=shader
 if digits!=4:
  ranks=256//digits
  text=text.replace('if (blocks <= 128u) { return; }',f'if (blocks <= 128u || group.x >= {256//digits}u) {{ return; }}').replace('group.x * 4u + (lid.x & 3u)',f'group.x * {digits}u + (lid.x & {digits-1}u)').replace('lid.x >> 2u',f'lid.x >> {int(math.log2(digits))}u').replace('(blocks + 63u) / 64u',f'(blocks + {ranks-1}u) / {ranks}u').replace('var offset = 4u;',f'var offset = {digits}u;').replace('rank == 63u',f'rank == {ranks-1}u')
 (folder/'shaders/physics_deterministic_primitives.wgsl').write_text(text)
for count in [262144,1048576]:
 for repeat in range(3):
  for digits in ([4,8,16,32] if repeat%2==0 else [32,16,8,4]):
   env=os.environ|{'VOXY_RADIX_RECORDS':str(count),'VOXY_RADIX_FRAMES':'300'}
   p=subprocess.run([str(root/'candidate/gpu_radix_static')],cwd=root/f'tile-{digits}',env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
   name=f'radix-tile-{digits}-{count}-{repeat}.log';(root/name).write_text(p.stdout)
   row={'digits':digits,'records':count,'repeat':repeat,'exit_code':p.returncode,'log':name,'summary':next((l for l in p.stdout.splitlines() if l.startswith('gpu_radix ')),None)}
   rows.append(row);(root/'radix-tiles.json').write_text(json.dumps(rows,indent=2));print(row,flush=True)
   if p.returncode:raise SystemExit(p.returncode)
