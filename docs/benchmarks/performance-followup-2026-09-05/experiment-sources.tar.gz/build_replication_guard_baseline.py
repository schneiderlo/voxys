import json,shlex,subprocess
from pathlib import Path
root=Path.cwd();build=Path('/tmp/voxys-perf-audit/cmake');dest=Path('/tmp/voxys-perf-followup')
data=json.loads((build/'compile_commands.json').read_text());c=next(x for x in data if x['file'].endswith('/tests/replication_benchmark.cpp'));cmd=shlex.split(c['command']);cmd=cmd[:cmd.index('-o')];objects=[];commands=[]
for index,relative in enumerate(['tests/replication_benchmark.cpp','src/network/replication.cpp','src/network/multiplayer_session.cpp']):
 source=root/relative
 if index:
  source=dest/('baseline-'+Path(relative).name);source.write_bytes(subprocess.check_output(['git','show','6701a85:'+relative]))
 obj=dest/f'replication-baseline-guard-{index}.o';args=cmd+['-c',str(source),'-o',str(obj)];commands.append(args);subprocess.run(args,check=True);objects.append(str(obj))
args=[cmd[0],'-O3','-pthread',*objects,'-o',str(dest/'replication-baseline-guard'),str(build/'lib/libvoxy_core.a'),str(build/'lib/libgtest_main.a'),str(build/'lib/libgtest.a'),str(build/'lib/libzstd.a'),str(build/'lib/libminiz.a'),str(build/'lib/libJolt.a'),str(build/'lib/libbox3d.a'),'-lm','/nix/store/am7340xwv0wc7l8lcvzyag41a5m8p1pb-glfw-3.4/lib/libglfw.so.3.4',str(root/'third_party/wgpu-native/dist/lib/libwgpu_native.so'),'-ldl','-Wl,-rpath,'+str(root/'third_party/wgpu-native/dist/lib')];commands.append(args);subprocess.run(args,check=True);(dest/'replication-guard-build-commands.json').write_text(json.dumps(commands,indent=2))
