#include "network/multiplayer_session.hpp"
#include <algorithm>
#include <chrono>
#include <cstdlib>
#include <iostream>
#include <numeric>
#include <stdexcept>
using namespace voxy::network;
using namespace voxy::physics::deterministic;
struct Sink final:IMultiplayerTransport {
 uint64_t bytes=0,frames=0;
 bool send(uint32_t,DeliveryClass,std::span<const std::byte> data) override {bytes+=data.size();++frames;return true;}
 std::optional<MultiplayerTransportFrame> poll() override{return std::nullopt;}
 void close() override{}
};
int main(int argc,char** argv){
 const uint32_t count=argc>1?uint32_t(std::stoul(argv[1])):65536;
 const uint32_t clients=argc>2?uint32_t(std::stoul(argv[2])):12;
 const uint32_t frames=argc>3?uint32_t(std::stoul(argv[3])):2000;
 const bool dense=argc>4&&std::string_view(argv[4])=="dense";
 std::vector<LockstepBody> bodies(count);
 for(uint32_t i=1;i<count;++i){auto& b=bodies[i];b.identity={i,1,LockstepBodyAlive|LockstepBodyAwake,0};b.sectorRadius={int32_t(i%256)-128,0,int32_t(i/256)-128,kLockstepPositionOne/2};b.positionInvMass={0,4*kLockstepPositionOne,0,kLockstepVelocityOne};if(dense)b.sectorRadius[0]=b.sectorRadius[2]=0;}
 MultiplayerSession::ServerConfig cfg;cfg.identity={0x1002,0x2003,4};cfg.world.bodyCapacity=count;cfg.world.contactCapacity=64;cfg.world.gravityPerSubstepQ16=0;cfg.maximumClients=clients+2;cfg.interest.maximumEntries=count;cfg.snapshotHistoryTicks=16;
 auto sink=std::make_unique<Sink>();auto* transport=sink.get();MultiplayerSession session;
 if(!session.initializeServer(cfg,bodies,std::move(sink)))throw std::runtime_error("initialize");
 for(uint32_t i=1;i<=clients;++i)if(!session.addClient({i,i*(count/(clients+1)),2,256}))throw std::runtime_error("addClient");
 std::vector<double> samples; samples.reserve(frames);
 uint64_t hash=0;for(uint32_t i=1;i<=clients;++i){auto s=session.snapshotForClient(i);if(!s)throw std::runtime_error("snapshot");auto bytes=SnapshotCodec::encode(*s);for(auto x:bytes)hash=(hash^std::to_integer<uint8_t>(x))*1099511628211ull;}
 for(uint32_t f=0;f<frames+20;++f){auto start=std::chrono::steady_clock::now();if(!session.sendSnapshots())throw std::runtime_error("send");if(f>=20)samples.push_back(std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-start).count());}
 double total=std::accumulate(samples.begin(),samples.end(),0.0);std::sort(samples.begin(),samples.end());auto p=[&](size_t percent){return samples[(samples.size()*percent+99)/100-1];};
 std::cout<<"replication bodies="<<count<<" clients="<<clients<<" dense="<<dense<<" frames="<<frames<<" p50_ms="<<p(50)<<" p95_ms="<<p(95)<<" p99_ms="<<p(99)<<" rounds_per_s="<<1000*frames/total<<" bytes="<<transport->bytes<<" packets="<<transport->frames<<" oracle="<<std::hex<<hash<<'\n';
}
