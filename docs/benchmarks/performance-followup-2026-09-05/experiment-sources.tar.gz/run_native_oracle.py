import subprocess,json
from pathlib import Path
root=Path('/tmp/voxys-perf-followup');rows=[]
for version,repeat in [('original',0),('original',1),('candidate',0)]:
 output=root/f'native-oracle-{version}-{repeat}.png'
 args=[str(root/version/'voxy_native'),'--benchmark-bodies','100000','--benchmark-fixed-hz','400','--no-validation','--screenshot',str(output),'--screenshot-frames','200']
 p=subprocess.run(args,cwd=root/version,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
 (root/f'native-oracle-{version}-{repeat}.log').write_text(p.stdout)
 rows.append({'version':version,'repeat':repeat,'exit_code':p.returncode,'exists':output.exists(),'command':args});print(rows[-1],flush=True)
(root/'native-oracle.json').write_text(json.dumps(rows,indent=2))
