import json,shlex,subprocess
from pathlib import Path
root=Path.cwd();build=Path('/tmp/voxys-perf-audit/cmake');dest=Path('/tmp/voxys-perf-followup')
data=json.loads((build/'compile_commands.json').read_text());c=next(x for x in data if x['file'].endswith('/src/network/replication.cpp'))
cmd=shlex.split(c['command']);cmd=cmd[:cmd.index('-o')]
args=cmd+['-g','-fno-omit-frame-pointer','-c',str(dest/'replication_probe.cpp'),'-o',str(dest/'replication_probe.o')];subprocess.run(args,check=True)
args=[cmd[0],'-g',str(dest/'replication_probe.o'),'-o',str(dest/'replication-probe'),str(build/'lib/libvoxy_core.a'),str(build/'lib/libzstd.a'),str(build/'lib/libminiz.a'),str(build/'lib/libJolt.a'),str(build/'lib/libbox3d.a'),'-lm','/nix/store/am7340xwv0wc7l8lcvzyag41a5m8p1pb-glfw-3.4/lib/libglfw.so.3.4',str(root/'third_party/wgpu-native/dist/lib/libwgpu_native.so'),'-ldl','-pthread','-Wl,-rpath,'+str(root/'third_party/wgpu-native/dist/lib')];subprocess.run(args,check=True)
