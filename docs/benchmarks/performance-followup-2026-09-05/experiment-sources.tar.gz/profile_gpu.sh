#!/usr/bin/env bash
set -euo pipefail
export VOXY_GPU_TIMESTAMP_PERIOD_NS=10.019
export VOXY_GPU_BALLISTIC_BODIES=100000
export VOXY_GPU_BALLISTIC_WARMUP_FRAMES=20
export VOXY_GPU_BALLISTIC_MEASURED_FRAMES=1000
env LD_PRELOAD=/nix/store/brivbydwp5ykjhaw8pnc2kf3jrni24bz-gperftools-2.17.2/lib/libprofiler.so CPUPROFILE=/tmp/voxys-perf-followup/gpu.cpu CPUPROFILE_FREQUENCY=1000 ./bazel-bin/tests/gpu_ballistic_benchmark > /tmp/voxys-perf-followup/gpu-cpu-run.log 2>&1
/nix/store/6gdpgjrgrg592sgcbzklq2r89mbwk4yl-pprof-0-unstable-2026-03-02/bin/pprof -top -nodecount=20 ./bazel-bin/tests/gpu_ballistic_benchmark /tmp/voxys-perf-followup/gpu.cpu > /tmp/voxys-perf-followup/gpu-cpu-top.txt 2>&1
export VOXY_GPU_BALLISTIC_MEASURED_FRAMES=300
/nix/store/565m73i63yx2wz48248jlmjyb41qb647-heaptrack-1.5.0-unstable-2025-07-21/bin/heaptrack --record-only -o /tmp/voxys-perf-followup/gpu-heap ./bazel-bin/tests/gpu_ballistic_benchmark > /tmp/voxys-perf-followup/gpu-heap.log 2>&1
strace -f -c -o /tmp/voxys-perf-followup/gpu-io.txt ./bazel-bin/tests/gpu_ballistic_benchmark > /tmp/voxys-perf-followup/gpu-io-run.log 2>&1
