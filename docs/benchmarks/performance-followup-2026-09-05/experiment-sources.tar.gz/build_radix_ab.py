import json,shlex,subprocess
from pathlib import Path
root=Path.cwd();build=Path('/tmp/voxys-perf-audit/cmake');dest=Path('/tmp/voxys-perf-followup')
data=json.loads((build/'compile_commands.json').read_text()); c=next(x for x in data if x['file'].endswith('/tests/gpu_ballistic_benchmark.cpp'))
base=shlex.split(c['command']);base=base[:base.index('-o')]
old=dest/'old-include/physics/gpu';old.mkdir(parents=True,exist_ok=True)
for name in ['deterministic_primitives.hpp','deterministic_primitives.cpp']:
 (old/name).write_bytes(subprocess.check_output(['git','show','6701a85:src/physics/gpu/'+name]))
commands=[]
for version in ['original','candidate']:
 flags=base[:1]+(['-I'+str(dest/'old-include')] if version=='original' else [])+base[1:]
 files=[root/'tests/gpu_radix_benchmark.cpp',old/'deterministic_primitives.cpp' if version=='original' else root/'src/physics/gpu/deterministic_primitives.cpp']
 objs=[]
 for idx,source in enumerate(files):
  obj=dest/version/f'radix-{idx}.o';args=flags+['-c',str(source),'-o',str(obj)];commands.append(args);subprocess.run(args,check=True);objs.append(str(obj))
 args=[base[0],'-O3','-pthread',*objs,'-o',str(dest/version/'gpu_radix_static'),str(build/'lib/libvoxy_core.a'),str(build/'lib/libgtest_main.a'),str(build/'lib/libgtest.a'),str(build/'lib/libzstd.a'),str(build/'lib/libminiz.a'),str(build/'lib/libJolt.a'),str(build/'lib/libbox3d.a'),'-lm','/nix/store/am7340xwv0wc7l8lcvzyag41a5m8p1pb-glfw-3.4/lib/libglfw.so.3.4',str(root/'third_party/wgpu-native/dist/lib/libwgpu_native.so'),'-ldl','-Wl,-rpath,'+str(root/'third_party/wgpu-native/dist/lib')]
 commands.append(args);subprocess.run(args,check=True)
(dest/'radix-ab-build-commands.json').write_text(json.dumps(commands,indent=2))
