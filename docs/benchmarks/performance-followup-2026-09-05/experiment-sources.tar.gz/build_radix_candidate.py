import json,shlex,subprocess
from pathlib import Path
root=Path.cwd(); build=Path('/tmp/voxys-perf-audit/cmake'); dest=Path('/tmp/voxys-perf-followup')
data=json.loads((build/'compile_commands.json').read_text());c=next(x for x in data if x['file'].endswith('/src/physics/gpu/deterministic_primitives.cpp'))
cmd=shlex.split(c['command']);cmd=cmd[:cmd.index('-o')];cmd+=['-g','-fno-omit-frame-pointer','-include','gpu/webgpu_compat.hpp']
commands=[]
for name in ['primitives-candidate','radix_probe']:
 args=cmd+['-c',str(dest/(name+'.cpp')),'-o',str(dest/(name+'.o'))];commands.append(args);subprocess.run(args,check=True)
args=[cmd[0],'-g',str(dest/'radix_probe.o'),str(dest/'primitives-candidate.o'),'-o',str(dest/'radix-candidate'),str(build/'lib/libvoxy_core.a'),str(build/'lib/libzstd.a'),str(build/'lib/libminiz.a'),str(build/'lib/libJolt.a'),str(build/'lib/libbox3d.a'),'-lm','/nix/store/am7340xwv0wc7l8lcvzyag41a5m8p1pb-glfw-3.4/lib/libglfw.so.3.4',str(root/'third_party/wgpu-native/dist/lib/libwgpu_native.so'),'-ldl','-pthread','-Wl,-rpath,'+str(root/'third_party/wgpu-native/dist/lib')]
commands.append(args);subprocess.run(args,check=True);(dest/'radix-candidate-build-commands.json').write_text(json.dumps(commands,indent=2))
