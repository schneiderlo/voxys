import os,subprocess,json,re
from pathlib import Path
root=Path('/tmp/voxys-perf-followup');results=[]
for count,frames,repeats in [(100,300,2),(1000,300,2),(10000,300,2),(100000,300,3)]:
 for repeat in range(repeats):
  for version in (['original','candidate'] if repeat%2==0 else ['candidate','original']):
   env=os.environ|{'VOXY_GPU_TIMESTAMP_PERIOD_NS':'10.019','VOXY_GPU_BALLISTIC_BODIES':str(count),'VOXY_GPU_BALLISTIC_WARMUP_FRAMES':'20','VOXY_GPU_BALLISTIC_MEASURED_FRAMES':str(frames)}
   cmd=['/usr/bin/time','-v',str(root/version/'gpu_ballistic_static')]
   run=subprocess.run(cmd,cwd=root/version,env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
   name=f'gpu-{count}-{version}-{repeat}.log';(root/name).write_text(run.stdout)
   summary=next((l for l in run.stdout.splitlines() if l.startswith('gpu_ballistic ')),None)
   row={'bodies':count,'version':version,'repeat':repeat,'exit_code':run.returncode,'log':name,'summary':summary}
   results.append(row);(root/'gpu-ab.json').write_text(json.dumps(results,indent=2));print(row,flush=True)
   if run.returncode:raise SystemExit(run.returncode)
