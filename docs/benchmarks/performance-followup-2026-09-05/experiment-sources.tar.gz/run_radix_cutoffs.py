import os,subprocess,json
from pathlib import Path
root=Path('/tmp/voxys-perf-followup');shader=Path('shaders/physics_deterministic_primitives.wgsl').read_text();rows=[]
for cutoff in [16,32,64,128]:
 folder=root/f'cutoff-{cutoff}';(folder/'shaders').mkdir(parents=True,exist_ok=True)
 text=shader.replace('blocks <= 128u',f'blocks <= {cutoff}u').replace('radix_block_count() > 128u',f'radix_block_count() > {cutoff}u')
 (folder/'shaders/physics_deterministic_primitives.wgsl').write_text(text)
for count in [4096,8192,10000,16384,32768,65536]:
 for repeat in range(3):
  for cutoff in ([16,32,64,128] if repeat%2==0 else [128,64,32,16]):
   env=os.environ|{'VOXY_RADIX_RECORDS':str(count),'VOXY_RADIX_CAPACITY':'262144','VOXY_RADIX_FRAMES':'1000'}
   p=subprocess.run([str(root/'candidate/gpu_radix_static')],cwd=root/f'cutoff-{cutoff}',env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
   name=f'radix-cutoff-{cutoff}-{count}-{repeat}.log';(root/name).write_text(p.stdout)
   row={'cutoff':cutoff,'records':count,'repeat':repeat,'exit_code':p.returncode,'log':name,'summary':next((l for l in p.stdout.splitlines() if l.startswith('gpu_radix ')),None)}
   rows.append(row);(root/'radix-cutoffs.json').write_text(json.dumps(rows,indent=2));print(row,flush=True)
   if p.returncode:raise SystemExit(p.returncode)
