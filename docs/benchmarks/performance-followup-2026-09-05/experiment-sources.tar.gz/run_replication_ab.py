import subprocess,json
from pathlib import Path
root=Path('/tmp/voxys-perf-followup');rows=[]
for count in [4096,65536]:
 for layout in ['sparse','dense']:
  for repeat in range(5):
   for version in (['original','candidate'] if repeat%2==0 else ['candidate','original']):
    binary='replication-probe' if version=='original' else 'replication-candidate'
    args=['/usr/bin/time','-v',str(root/binary),str(count),'12','2000' if layout=='sparse' else '300',layout]
    p=subprocess.run(args,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    name=f'replication-{count}-{layout}-{version}-{repeat}.log';(root/name).write_text(p.stdout)
    row={'bodies':count,'layout':layout,'version':version,'repeat':repeat,'exit_code':p.returncode,'log':name,'summary':next((l for l in p.stdout.splitlines() if l.startswith('replication bodies')),None)}
    rows.append(row);(root/'replication-ab.json').write_text(json.dumps(rows,indent=2));print(row,flush=True)
    if p.returncode:raise SystemExit(p.returncode)
