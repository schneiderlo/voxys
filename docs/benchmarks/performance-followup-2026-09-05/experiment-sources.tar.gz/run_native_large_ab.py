import subprocess,json
from pathlib import Path
root=Path('/tmp/voxys-perf-followup');rows=[]
for repeat in range(3):
 for version in (['original','candidate'] if repeat%2==0 else ['candidate','original']):
  cmd=['/usr/bin/time','-v',str(root/version/'voxy_native'),'--benchmark-bodies','100000','--benchmark-fixed-hz','400','--no-validation']
  run=subprocess.run(cmd,cwd=root/version,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
  name=f'native-100000-{version}-{repeat}.log';(root/name).write_text(run.stdout)
  summary=[l for l in run.stdout.splitlines() if 'Overall Throughput:' in l or 'Complete:' in l or 'Maximum resident set size' in l]
  row={'version':version,'repeat':repeat,'exit_code':run.returncode,'log':name,'summary':summary};rows.append(row);(root/'native-large-ab.json').write_text(json.dumps(rows,indent=2));print(row,flush=True)
  if run.returncode:raise SystemExit(run.returncode)
