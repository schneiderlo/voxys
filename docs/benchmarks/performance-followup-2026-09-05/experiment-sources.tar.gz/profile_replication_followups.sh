#!/usr/bin/env bash
set -euo pipefail
profiler=/nix/store/brivbydwp5ykjhaw8pnc2kf3jrni24bz-gperftools-2.17.2/lib/libprofiler.so
pprof=/nix/store/6gdpgjrgrg592sgcbzklq2r89mbwk4yl-pprof-0-unstable-2026-03-02/bin/pprof
root=/tmp/voxys-perf-followup
env LD_PRELOAD="$profiler" CPUPROFILE="$root/replication-dense.cpu" CPUPROFILE_FREQUENCY=1000 "$root/replication-probe" 65536 12 1000 dense > "$root/replication-dense-cpu-run.log" 2>&1
"$pprof" -top -nodecount=20 "$root/replication-probe" "$root/replication-dense.cpu" > "$root/replication-dense-cpu-top.txt" 2>&1
env LD_PRELOAD="$profiler" CPUPROFILE="$root/replication-after.cpu" CPUPROFILE_FREQUENCY=1000 "$root/replication-candidate" 65536 12 500000 > "$root/replication-after-cpu-run.log" 2>&1
"$pprof" -top -nodecount=20 "$root/replication-candidate" "$root/replication-after.cpu" > "$root/replication-after-cpu-top.txt" 2>&1
