#include "gpu/context.hpp"
#include "gpu/resources.hpp"
#include "physics/gpu/gpu_body_metadata.hpp"
#include "render/primitive_gpu_culling.hpp"
#include <algorithm>
#include <array>
#include <chrono>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <numeric>
#include <span>
#include <vector>
#include <sys/resource.h>
using WGPUSubmissionIndex = uint64_t;
struct WGPUWrappedSubmissionIndex { WGPUQueue queue; WGPUSubmissionIndex submissionIndex; };
extern "C" WGPUSubmissionIndex wgpuQueueSubmitForIndex(WGPUQueue,size_t,const WGPUCommandBuffer*);
extern "C" WGPUBool wgpuDevicePoll(WGPUDevice,WGPUBool,const WGPUWrappedSubmissionIndex*);
namespace voxy::render { WGPUQuerySet cullProfileQuerySet = nullptr; }
using namespace voxy;
struct alignas(16) Pose { glm::vec4 p{0,0,0.5,1}; glm::vec4 q{0,0,0,1}; };
struct alignas(16) Shape { glm::vec4 d{.1,.1,.1,0}; glm::vec4 p{}; glm::vec4 m{-1,-1,-1,1}; };
struct Args { uint32_t indices,instances,first; int32_t base; uint32_t firstInstance; };
using Clock=std::chrono::steady_clock;
double pct(std::vector<double> v,double q) { std::sort(v.begin(),v.end()); return v[std::min(v.size()-1,size_t(std::ceil(q*v.size()))-1)]; }
void check(bool b) { if(!b) { std::cerr<<"oracle/resource failure\n"; std::exit(2); } }
std::vector<std::byte> read(gpu::Context& ctx,WGPUBuffer b,size_t n,const WGPUWrappedSubmissionIndex& si) {
 struct State {bool done=false,ok=false;} state;
 wgpuBufferMapAsync(b,WGPUMapMode_Read,0,n,[](WGPUBufferMapAsyncStatus s,void* p){auto& r=*static_cast<State*>(p);r.ok=s==WGPUBufferMapAsyncStatus_Success;r.done=true;},&state);
 while(!state.done) wgpuDevicePoll(ctx.getDevice(),true,&si);
 check(state.ok);std::vector<std::byte> out(n);const void* p=wgpuBufferGetConstMappedRange(b,0,n);check(p);std::memcpy(out.data(),p,n);wgpuBufferUnmap(b);return out;
}
int main(int argc,char** argv) {
 const uint32_t n=argc>1?uint32_t(std::stoul(argv[1])):100000;
 const uint32_t frames=argc>2?uint32_t(std::stoul(argv[2])):300;
 const bool profile=argc>3?std::stoi(argv[3])!=0:true;
 const char* shader=argc>4?argv[4]:"shaders/physics_primitive_cull.wgsl";
 check(n>0&&n<=1048576&&frames>0);
 gpu::Context ctx;gpu::ContextConfig cfg;cfg.enableValidation=false;cfg.enableTimestamps=profile;check(ctx.initHeadless(cfg));
 std::vector<Pose> poses(n);std::vector<Shape> shapes(n);std::vector<glm::uvec4> meta(n);
 std::array<std::vector<uint32_t>,5> golden;
 for(uint32_t i=0;i<n;++i) {
  shapes[i].d.w=float(i%5);meta[i]={0,0,0,physics::packGpuBodyMetadata(1,physics::kGpuBodyAliveFlag)};
  if(i%11==0) poses[i].p.x=10;
  else if(i%17==0) meta[i].w=0;
  else if(i%19==0) shapes[i].d.x=shapes[i].d.y=shapes[i].d.z=0;
  else golden[i%5].push_back(i);
 }
 auto storage=[&]<class T>(const std::vector<T>& v) {return gpu::createBufferWithData(ctx.getDevice(),ctx.getQueue(),gpu::BufferDesc::storage(v.size()*sizeof(T),false,"probe_input"),std::span<const T>(v));};
 WGPUBuffer pb=storage(poses),sb=storage(shapes),mb=storage(meta);check(pb&&sb&&mb);
 std::array<render::PrimitiveDrawGeometry,5> geo;for(uint32_t i=0;i<5;++i)geo[i]={100+i,200+i*10};
 render::PrimitiveGpuCulling cull;check(cull.initialize(ctx.getDevice(),ctx.getQueue(),shader,geo));check(cull.setBodyView({.poseBuffer=pb,.shapeBuffer=sb,.metadataBuffer=mb,.residentBodyCapacity=n,.shapeCount=5}));
 WGPUBuffer resolve=nullptr,timingRead=nullptr;
 if(profile) {
  WGPUQuerySetDescriptor d{};d.type=WGPUQueryType_Timestamp;d.count=8;render::cullProfileQuerySet=wgpuDeviceCreateQuerySet(ctx.getDevice(),&d);check(render::cullProfileQuerySet);
  resolve=gpu::createBuffer(ctx.getDevice(),{.label="probe_resolve",.size=64,.usage=WGPUBufferUsage_QueryResolve|WGPUBufferUsage_CopySrc});
  timingRead=gpu::createBuffer(ctx.getDevice(),{.label="probe_timing",.size=64,.usage=WGPUBufferUsage_CopyDst|WGPUBufferUsage_MapRead});check(resolve&&timingRead);
 }
 std::vector<double> times;times.reserve(frames);std::array<std::vector<double>,4> stages;for(auto& s:stages)s.reserve(frames);
 uint64_t hash=14695981039346656037ull;
 for(uint32_t f=0;f<frames+20;++f) {
  auto start=Clock::now();WGPUCommandEncoderDescriptor ed{};auto enc=wgpuDeviceCreateCommandEncoder(ctx.getDevice(),&ed);check(cull.encode(enc,glm::mat4(1)));
  if(profile){wgpuCommandEncoderResolveQuerySet(enc,render::cullProfileQuerySet,0,8,resolve,0);wgpuCommandEncoderCopyBufferToBuffer(enc,resolve,0,timingRead,0,64);}
  WGPUCommandBufferDescriptor cd{};auto cmd=wgpuCommandEncoderFinish(enc,&cd);check(cmd);WGPUWrappedSubmissionIndex si{ctx.getQueue(),wgpuQueueSubmitForIndex(ctx.getQueue(),1,&cmd)};wgpuDevicePoll(ctx.getDevice(),true,&si);
  const double elapsed=std::chrono::duration<double,std::milli>(Clock::now()-start).count();
  if(f>=20)times.push_back(elapsed);
  if(profile){auto bytes=read(ctx,timingRead,64,si);std::array<uint64_t,8> ts;std::memcpy(ts.data(),bytes.data(),64);if(f>=20)for(size_t j=0;j<4;++j)stages[j].push_back(double(ts[2*j+1]-ts[2*j])*10.019e-6);}
  wgpuCommandBufferRelease(cmd);wgpuCommandEncoderRelease(enc);
  if(f==19||f==frames+19) {
   size_t bytes=100+size_t(cull.segmentCapacity())*5*4;
   auto rb=gpu::createBuffer(ctx.getDevice(),{.label="probe_oracle",.size=bytes,.usage=WGPUBufferUsage_MapRead|WGPUBufferUsage_CopyDst});check(rb);
   enc=wgpuDeviceCreateCommandEncoder(ctx.getDevice(),&ed);wgpuCommandEncoderCopyBufferToBuffer(enc,cull.indirectDrawArgs(),0,rb,0,100);wgpuCommandEncoderCopyBufferToBuffer(enc,cull.visibleBodyIds(),0,rb,100,bytes-100);cmd=wgpuCommandEncoderFinish(enc,&cd);si={ctx.getQueue(),wgpuQueueSubmitForIndex(ctx.getQueue(),1,&cmd)};auto data=read(ctx,rb,bytes,si);
   for(size_t j=0;j<5;++j){Args a;std::memcpy(&a,data.data()+j*20,20);check(a.indices==geo[j].indexCount&&a.first==geo[j].firstIndex&&a.instances==golden[j].size()&&a.base==0&&a.firstInstance==0);for(size_t k=0;k<golden[j].size();++k){uint32_t id;std::memcpy(&id,data.data()+100+(j*cull.segmentCapacity()+k)*4,4);check(id==golden[j][k]);if(f==19){hash^=id;hash*=1099511628211ull;}}}
   wgpuBufferDestroy(rb);wgpuBufferRelease(rb);wgpuCommandBufferRelease(cmd);wgpuCommandEncoderRelease(enc);
  }
 }
 rusage usage{};getrusage(RUSAGE_SELF,&usage);
 std::cout<<"cull bodies="<<n<<" frames="<<frames<<" profile="<<profile<<" p50_ms="<<pct(times,.5)<<" p95_ms="<<pct(times,.95)<<" p99_ms="<<pct(times,.99)<<" queries_per_s="<<1000*frames/std::accumulate(times.begin(),times.end(),0.)<<" rss_kib="<<usage.ru_maxrss<<" golden_hash="<<std::hex<<hash<<std::dec<<"\n";
 const char* names[]={"rebase","cull_blocks","scan_blocks","scatter"};if(profile)for(size_t j=0;j<4;++j)std::cout<<"stage="<<names[j]<<" p50_ms="<<pct(stages[j],.5)<<" p95_ms="<<pct(stages[j],.95)<<" p99_ms="<<pct(stages[j],.99)<<"\n";
 cull.shutdown();for(auto b:{pb,sb,mb,resolve,timingRead})if(b){wgpuBufferDestroy(b);wgpuBufferRelease(b);}if(render::cullProfileQuerySet)wgpuQuerySetRelease(render::cullProfileQuerySet);
}
