#!/usr/bin/env bash
set -euo pipefail
probe=/tmp/voxys-perf-followup/replication-probe
for bodies in 4096 65536; do
  /usr/bin/time -v "$probe" "$bodies" 12 2000 > "/tmp/voxys-perf-followup/replication-${bodies}-sparse.log" 2>&1
  /usr/bin/time -v "$probe" "$bodies" 12 1000 dense > "/tmp/voxys-perf-followup/replication-${bodies}-dense.log" 2>&1
done
env LD_PRELOAD=/nix/store/brivbydwp5ykjhaw8pnc2kf3jrni24bz-gperftools-2.17.2/lib/libprofiler.so CPUPROFILE=/tmp/voxys-perf-followup/replication.cpu CPUPROFILE_FREQUENCY=1000 "$probe" 65536 12 20000 > /tmp/voxys-perf-followup/replication-cpu-run.log 2>&1
/nix/store/6gdpgjrgrg592sgcbzklq2r89mbwk4yl-pprof-0-unstable-2026-03-02/bin/pprof -top -nodecount=25 "$probe" /tmp/voxys-perf-followup/replication.cpu > /tmp/voxys-perf-followup/replication-cpu-top.txt 2>&1
/nix/store/565m73i63yx2wz48248jlmjyb41qb647-heaptrack-1.5.0-unstable-2025-07-21/bin/heaptrack --record-only -o /tmp/voxys-perf-followup/replication-heap "$probe" 65536 12 2000 > /tmp/voxys-perf-followup/replication-heap.log 2>&1
/nix/store/565m73i63yx2wz48248jlmjyb41qb647-heaptrack-1.5.0-unstable-2025-07-21/bin/heaptrack_print /tmp/voxys-perf-followup/replication-heap.zst > /tmp/voxys-perf-followup/replication-allocations.txt 2>&1
strace -f -c -o /tmp/voxys-perf-followup/replication-io.txt "$probe" 65536 12 2000 > /tmp/voxys-perf-followup/replication-io-run.log 2>&1
