#!/usr/bin/env bash
set -euo pipefail
root=/tmp/voxys-perf-followup
for layout in sparse dense; do
  limit=100
  dense=0
  if [[ "$layout" == dense ]]; then limit=3500; dense=1; fi
  env VOXY_REPLICATION_FRAMES=500 VOXY_REPLICATION_DENSE="$dense" VOXY_REPLICATION_MAX_P95_US="$limit" "$root/replication-baseline-guard" > "$root/replication-original-$layout-guard.log" 2>&1 && code=0 || code=$?
  printf 'Original replication %s guard exit (expected 1): %s\n' "$layout" "$code"
  [[ "$code" == 1 ]]
done
heaptrack=/nix/store/565m73i63yx2wz48248jlmjyb41qb647-heaptrack-1.5.0-unstable-2025-07-21/bin/heaptrack
printer=/nix/store/565m73i63yx2wz48248jlmjyb41qb647-heaptrack-1.5.0-unstable-2025-07-21/bin/heaptrack_print
for version in before after; do
 binary=replication-probe
 if [[ "$version" == after ]]; then binary=replication-ranked; fi
 "$heaptrack" --record-only -o "$root/replication-dense-heap-$version" "$root/$binary" 65536 12 300 dense > "$root/replication-dense-heap-$version.log" 2>&1
 "$printer" "$root/replication-dense-heap-$version.zst" > "$root/replication-dense-heap-$version.txt" 2>&1
done
