#!/usr/bin/env bash
set -euo pipefail
root=/tmp/voxys-perf-followup
/usr/bin/time -v env VOXY_RADIX_MAX_P95_US=4500 VOXY_RADIX_MAX_SCRATCH_BYTES=8406032 ./bazel-bin/tests/gpu_radix_benchmark > "$root/radix-guard.log" 2>&1
/usr/bin/time -v env VOXY_REPLICATION_MAX_P95_US=100 ./bazel-bin/tests/replication_benchmark > "$root/replication-guard.log" 2>&1
/usr/bin/time -v env VOXY_REPLICATION_DENSE=1 VOXY_REPLICATION_FRAMES=500 VOXY_REPLICATION_MAX_P95_US=3500 ./bazel-bin/tests/replication_benchmark > "$root/replication-dense-guard.log" 2>&1
/usr/bin/time -v env VOXY_RADIX_MAX_P95_US=4500 VOXY_RADIX_MAX_SCRATCH_BYTES=8406032 /tmp/voxys-perf-audit/cmake/bin/gpu_radix_benchmark > "$root/radix-cmake-guard.log" 2>&1
/usr/bin/time -v env VOXY_REPLICATION_MAX_P95_US=100 /tmp/voxys-perf-audit/cmake/bin/replication_benchmark > "$root/replication-cmake-guard.log" 2>&1
(cd "$root/original" && env VOXY_RADIX_MAX_P95_US=4500 ./gpu_radix_static) > "$root/radix-original-guard.log" 2>&1 && code=0 || code=$?
printf 'Original radix guard exit status (expected 1): %s\n' "$code"
[[ "$code" == 1 ]]
env VOXY_RADIX_REPORT="$root/radix-final-web-report.json" node scripts/test_radix_histogram_prefix.mjs > "$root/radix-final-web.log" 2>&1
