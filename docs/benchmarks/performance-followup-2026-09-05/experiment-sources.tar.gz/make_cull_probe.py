from pathlib import Path
p=Path('/tmp/voxys-perf-followup')
s=Path('src/render/primitive_gpu_culling.cpp').read_text()
s=s.replace('namespace voxy::render {','namespace voxy::render {\nextern WGPUQuerySet cullProfileQuerySet;',1)
pos=s.index('    WGPUComputePassDescriptor passDesc{};',s.index('bool PrimitiveGpuCulling::encode('))
s=s[:pos]+s[pos:].replace('    WGPUComputePassDescriptor passDesc{};', '''    gpu::CompatPassTimestampWrites profileWrites{};
    profileWrites.querySet = cullProfileQuerySet;
    profileWrites.beginningOfPassWriteIndex = 0;
    profileWrites.endOfPassWriteIndex = 1;
    WGPUComputePassDescriptor passDesc{};
    if (cullProfileQuerySet) passDesc.timestampWrites = &profileWrites;''',1)
for marker, idx in [('    wgpuComputePassEncoderSetBindGroup(pass, 0, bindGroup_, 0, nullptr);',2),('    wgpuComputePassEncoderSetPipeline(pass, scanPipeline_);',4),('    wgpuComputePassEncoderSetPipeline(pass, scatterPipeline_);',6)]:
 s=s.replace(marker, f'''    if (cullProfileQuerySet) {{
        wgpuComputePassEncoderEnd(pass);
        wgpuComputePassEncoderRelease(pass);
        profileWrites.beginningOfPassWriteIndex = {idx};
        profileWrites.endOfPassWriteIndex = {idx+1};
        pass = wgpuCommandEncoderBeginComputePass(encoder, &passDesc);
        wgpuComputePassEncoderSetBindGroup(pass, 0, bindGroup_, 0, nullptr);
    }}
'''+marker,1)
(p/'culling-observed.cpp').write_text(s)
