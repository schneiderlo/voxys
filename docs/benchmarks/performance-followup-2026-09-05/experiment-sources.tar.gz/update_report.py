from pathlib import Path
import json
p=Path('docs/performance-followup-2026-09-05.md');s=p.read_text()
s=s.replace('Two independent changes','Three independent changes').replace('**17.1%**','**15.7%**').replace('**14.6%**','**13.7%**')
s=s.replace('- **Interest queries:** sparse, 12-peer snapshot fan-out fell from **0.323 ms to 0.011 ms** at the median. Dense fan-out stayed essentially unchanged.','- **Interest queries:** sparse, 12-peer snapshot fan-out fell from **0.321 ms to 0.011 ms** at the median.\n- **Distance precomputation:** dense fan-out fell from **5.23 ms to 1.97 ms**, with identical encoded snapshots.')
s=s.replace('Scores were recorded before each corresponding production edit.','Scores were recorded before each corresponding production edit.')
s=s.replace('| Precompute per-body interest distance | — | — | — | — | Dense-scene lead; separate profile required |','| Precompute per-body interest distance | 4 | 0.99 | 2 | 1.98 | Implement after dense caller profile |')
s=s.replace('at most 128 active histogram blocks','at most 32 active histogram blocks').replace('both sides of the 128-block boundary','both sides of the 32-block boundary').replace('**62,945,280 words**','**81,828,864 words**').replace('including 0, 128, 129, and 4,097 blocks','including 0, 31, 32, 33, 128, 129, and 4,097 blocks')
start=s.index('| 100k physics / before');end=s.index('\n\nThe 100k comparison',start)
s=s[:start]+'''| 100k physics / before | 14.290 | 15.082 | 15.441 | 69.882 frames |
| 100k physics / after | 12.331 | 13.208 | 14.320 | 80.820 frames |
| 10k sparse physics / before | 2.821 | 3.442 | 3.665 | 350.251 frames |
| 10k sparse physics / after | 2.669 | 3.301 | 3.668 | 357.587 frames |
| 10k contact stress / before | 3.446 | 6.124 | 6.638 | 246.919 frames |
| 10k contact stress / after | 3.209 | 5.770 | 6.249 | 262.646 frames |
| 262,144-record sort / before | 5.186 | 6.258 | 6.381 | 189.128 sorts |
| 262,144-record sort / after | 2.210 | 3.381 | 3.791 | 406.972 sorts |
| 1,048,576-record sort / before | 18.844 | 19.606 | 20.379 | 53.014 sorts |
| 1,048,576-record sort / after | 8.767 | 9.905 | 10.635 | 115.130 sorts |'''+s[end:]
s=s.replace('**138,024 → 138,460 KiB**','**138,536 → 138,668 KiB**').replace('**84,808 → 84,576 KiB**','**84,336 → 84,648 KiB**').replace('**113,800 → 113,888 KiB**','**113,908 → 113,776 KiB**')
start=s.index('Small dynamic inputs in a large allocation');end=s.index('\nA 4/8/16/32-digit',start)
s=s[:start]+'''Small dynamic inputs in a large allocation still incur an extra no-op dispatch. At capacity 262,144, 100 live records measured **0.210 → 0.280 ms** median in the final three-run matrix (the earlier matrix showed **0.203 → 0.217 ms**). This is a real observed small-input cost, with host timing variation; no universal speedup is claimed. Small allocations retain the old dispatch count. At 10,000 live records in a large allocation, the final cutoff improves the median **0.354 → 0.275 ms**.

The initial implementation used a 128-block crossover. Its 10k native control regressed 2.9%. A 72-run cutoff sweep showed that the parallel path helps much earlier: at 10,000 records, cutoff 32 improved p50/p95 **0.360/1.024 → 0.289/0.885 ms** relative to cutoff 128. The final implementation uses 32; both host and shader conditions, boundary tests, and full caller A/B were updated together. Initial results remain in the evidence.

The native five-view terrain/ocean benchmark now measures **585.4 → 615.8 FPS** median at 10,000 bodies (+5.2%, five alternating runs), with peak RSS **448,852 → 449,236 KiB**. At 100,000 bodies it measures **133.3 → 142.2 FPS** (+6.7%, three runs), with peak RSS **484,244 → 484,444 KiB**. View-five p95/p99 medians improve **46.11/47.92 → 42.51/43.81 ms** at 100k and **7.51/9.35 → 7.10/8.98 ms** at 10k. One 10k candidate run remains slower than its paired baseline. These cached, batched-retirement view measurements are not displayed-match frame pacing.
''' +s[end:]
marker='## Regression guardrails and exact commands'
section='''## Change 3: precompute snapshot selection distances

Production file: `src/network/multiplayer_session.cpp`. This is a separate lever from the indexed query. The dense caller profile measured **63.14% self CPU in `InterestGrid::cellFor`**, **13.84% in query scanning**, and **10.82% in merge sort**, over 5.572 sampled seconds. The comparator was repeatedly performing the same three integer divisions for each side of each comparison.

The new code computes each candidate's existing unsigned 64-bit squared cell distance once, then stable-sorts `(distance, bodyId)` records. It writes those IDs back into the existing ID vector. Truncation and snapshot construction remain unchanged. No state persists across calls.

### Equivalence proof

For a valid snapshot call, the world and grid do not change during selection. Each stored distance therefore equals every former comparator evaluation for that body. The pair comparison is the same lexicographic `(distance, bodyId)` order as the old comparator, including ties. Stable sorting keeps the same tie order. Subsequent truncation, controlled-body insertion, ID sorting, hashing, and encoding receive the same IDs in the same order. Integer expressions and widths are unchanged; no floating-point reassociation or cache invalidation assumption is introduced.

### Equivalence evidence and cost

The same sparse/dense baseline snapshot-byte goldens and packet counts pass. A new integration test checks exact encoded snapshot bytes for varied 3D distances, equal-distance ID ties, negative cell boundaries, out-of-range bodies, and four peer limits, including controlled-body-only output.

This trades extra bounded temporary memory for fewer repeated calculations. `rankedBodies` uses one 16-byte record per candidate on this ABI; stable-sort scratch can add another half-vector. The old ID vector is reused. There is no retained cache. The default query limit is 4,096; the extra peak temporary storage for that limit is roughly 88 KiB relative to the old sort. Sparse controlled-body-only queries allocate no rank records.

Five rotated-order repetitions isolate the two replication levers:

| Layout / implementation | p50 ms | p95 ms | p99 ms | Fan-out rounds/s |
|---|---:|---:|---:|---:|
| Sparse / original | 0.321087 | 0.463081 | 0.697747 | 2,919.22 |
| Sparse / indexed only | 0.010559 | 0.023213 | 0.030447 | 64,254.70 |
| Sparse / indexed + distances | 0.010810 | 0.015008 | 0.015579 | 84,205.70 |
| Dense / original | 5.232060 | 5.589620 | 8.790110 | 186.60 |
| Dense / indexed only | 5.317690 | 5.769630 | 7.200010 | 184.29 |
| Dense / indexed + distances | 1.970960 | 2.088390 | 2.689160 | 494.90 |

Median peak RSS: sparse **16,140 / 16,140 / 16,116 KiB**; dense **16,140 / 16,208 / 16,184 KiB** in the same order. RSS granularity and allocator variation do not establish that the new temporary vector is free; its bounded storage cost is explicit above.

'''
s=s.replace(marker,section+marker).replace('VOXY_REPLICATION_MAX_P95_US=8000','VOXY_REPLICATION_MAX_P95_US=3500')
s=s.replace('Per-query distance recomputation remains a dense generic-replication lead.','Per-query distance precomputation removes the measured dense generic-replication hotspot.')
s=s.replace('Per-query distance recomputation remains a dense generic-replication lead','Per-query distance precomputation removes the dense generic-replication hotspot')
p.write_text(s)
