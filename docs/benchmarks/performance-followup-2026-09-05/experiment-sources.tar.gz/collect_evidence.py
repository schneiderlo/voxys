from pathlib import Path
import json,gzip,hashlib,subprocess,tarfile,io,re,shutil
root=Path('/tmp/voxys-perf-followup');dest=Path('docs/benchmarks/performance-followup-2026-09-05');dest.mkdir(parents=True,exist_ok=True)
sections=['gpu-ab.json','gpu-confirm.json','gpu-final.json','native-ab.json','native-large-ab.json','native-final.json','radix-ab.json','radix-final.json','radix-tiles.json','radix-cutoffs.json','replication-ab.json','replication-final.json']
runs={}
for name in sections:
 rows=json.loads((root/name).read_text())
 for row in rows:
  row['log_text']=(root/row['log']).read_text()
 runs[name]=rows
with gzip.GzipFile(filename=str(dest/'runs.json.gz'),mode='wb',mtime=0) as f:f.write((json.dumps(runs,indent=2)+'\n').encode())
for name in ['summary.json','opportunity-matrix.txt','hardware-vulkan.txt','gpu-cpu-top.txt','gpu-allocations.txt','gpu-io.txt','replication-cpu-top.txt','replication-allocations.txt','replication-io.txt','replication-dense-cpu-top.txt','replication-after-cpu-top.txt','radix-final-web-report.json']:
 shutil.copy2(root/name,dest/name)
logs=['baseline-tests.log','final-complete-tests.log','baseline-build.log','2v2-baseline.log','shader-parity.log','gpu-baseline.log','native-baseline.log','native-10000-baseline.log','cull-baseline.log','cull-stages.log','radix-baseline.log','radix-stages.log','radix-candidate-stages.log','radix-guard.log','radix-cmake-guard.log','radix-original-guard.log','replication-guard.log','replication-cmake-guard.log','replication-dense-guard.log','final-complete-build.log','final-complete-guards.log']
compact={name:(root/name).read_text() for name in logs if (root/name).exists()}
for name in ['replication-original-sparse-guard.log','replication-original-dense-guard.log','replication-dense-heap-before.txt','replication-dense-heap-after.txt']:
 if (root/name).exists():compact[name]=(root/name).read_text()
(dest/'validation-and-profiles.json').write_text(json.dumps(compact,indent=2)+'\n')
with gzip.GzipFile(filename=str(dest/'test-details.json.gz'),mode='wb',mtime=0) as f:f.write(json.dumps({name:(root/name).read_text() for name in ['baseline-suite-detail.log','final-complete-suite-detail.log']}).encode())
# Preserve diagnostic sources, orchestration, exact compiler argv, and inputs.
sourceNames=[p for p in root.iterdir() if p.is_file() and (p.suffix in ['.py','.sh','.cpp'] or p.name.endswith('build-commands.json'))]
with tarfile.open(dest/'experiment-sources.tar.gz','w:gz') as archive:
 for p in sorted(sourceNames):archive.add(p,arcname=p.name)
 for version in ['original','candidate-128','candidate']:
  p=root/version/'shaders/physics_deterministic_primitives.wgsl';archive.add(p,arcname=version+'/shaders/'+p.name)
 for relative in ['src/physics/gpu/deterministic_primitives.hpp','src/physics/gpu/deterministic_primitives.cpp','src/network/replication.cpp','src/network/multiplayer_session.cpp']:
  data=subprocess.check_output(['git','show','6701a85:'+relative]);info=tarfile.TarInfo('baseline/'+relative);info.size=len(data);archive.addfile(info,io.BytesIO(data))
profiles={name:(root/name).read_bytes().hex() for name in ['gpu.cpu','replication.cpu','replication-dense.cpu','replication-after.cpu']}
with gzip.GzipFile(filename=str(dest/'cpu-profiles.json.gz'),mode='wb',mtime=0) as f:f.write(json.dumps(profiles).encode())
paths=[]
for version in ['original','candidate-128','candidate']:
 for name in ['voxy_native','gpu_ballistic_static','gpu_radix_static','shaders/physics_deterministic_primitives.wgsl']:
  p=root/version/name
  if p.exists():paths.append(p)
paths += list(root.glob('native-oracle-*.png'))
metadata={'baseline_commit':subprocess.check_output(['git','rev-parse','6701a85'],text=True).strip(),'goal_started_utc':'2026-09-05 12:43:23 UTC','planned_end_utc':'2026-09-05 14:43:23 UTC','host':subprocess.check_output(['uname','-a'],text=True).strip(),'cpu':subprocess.check_output(['lscpu'],text=True),'file_sha256':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths},'native_oracle':json.loads((root/'native-oracle.json').read_text()),'source_sha256':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [Path('AGENTS.md'),Path('README.md'),Path('shaders/physics_deterministic_primitives.wgsl'),Path('src/network/replication.cpp'),Path('src/network/multiplayer_session.cpp'),Path('src/physics/gpu/deterministic_primitives.cpp'),Path('src/physics/gpu/deterministic_primitives.hpp')]}}
(dest/'metadata.json').write_text(json.dumps(metadata,indent=2)+'\n')
