import os,subprocess,json
from pathlib import Path
root=Path('/tmp/voxys-perf-followup');rows=[]
for count,frames,repeats in [(10000,300,5),(10000,1000,5),(100000,300,5)]:
 for repeat in range(repeats):
  for version in (['original','candidate'] if repeat%2==0 else ['candidate','original']):
   env=os.environ|{'VOXY_GPU_TIMESTAMP_PERIOD_NS':'10.019','VOXY_GPU_BALLISTIC_BODIES':str(count),'VOXY_GPU_BALLISTIC_WARMUP_FRAMES':'20','VOXY_GPU_BALLISTIC_MEASURED_FRAMES':str(frames)}
   p=subprocess.run(['/usr/bin/time','-v',str(root/version/'gpu_ballistic_static')],cwd=root/version,env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
   name=f'gpu-final-{count}-{frames}-{version}-{repeat}.log';(root/name).write_text(p.stdout)
   row={'bodies':count,'frames':frames,'version':version,'repeat':repeat,'exit_code':p.returncode,'log':name,'summary':next((l for l in p.stdout.splitlines() if l.startswith('gpu_ballistic ')),None)}
   rows.append(row);(root/'gpu-final.json').write_text(json.dumps(rows,indent=2));print(row,flush=True)
   if p.returncode:raise SystemExit(p.returncode)
rows=[]
for count,repeats in [(10000,5),(100000,3)]:
 for repeat in range(repeats):
  for version in (['original','candidate'] if repeat%2==0 else ['candidate','original']):
   cmd=['/usr/bin/time','-v',str(root/version/'voxy_native'),'--benchmark-bodies',str(count),'--benchmark-fixed-hz','400','--no-validation']
   p=subprocess.run(cmd,cwd=root/version,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
   name=f'native-final-{count}-{version}-{repeat}.log';(root/name).write_text(p.stdout)
   summary=[l for l in p.stdout.splitlines() if 'Overall Throughput:' in l or 'Complete:' in l or 'Maximum resident set size' in l]
   row={'bodies':count,'version':version,'repeat':repeat,'exit_code':p.returncode,'log':name,'summary':summary};rows.append(row);(root/'native-final.json').write_text(json.dumps(rows,indent=2));print(row,flush=True)
   if p.returncode:raise SystemExit(p.returncode)
