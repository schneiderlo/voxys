#include "gpu/context.hpp"
#include "gpu/resources.hpp"
#include "physics/gpu/gpu_body_metadata.hpp"
#include "render/primitive_gpu_culling.hpp"
#include "physics/gpu/deterministic_primitives.hpp"
#include <algorithm>
#include <array>
#include <chrono>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <numeric>
#include <span>
#include <vector>
#include <sys/resource.h>
using WGPUSubmissionIndex = uint64_t;
struct WGPUWrappedSubmissionIndex { WGPUQueue queue; WGPUSubmissionIndex submissionIndex; };
extern "C" WGPUSubmissionIndex wgpuQueueSubmitForIndex(WGPUQueue,size_t,const WGPUCommandBuffer*);
extern "C" WGPUBool wgpuDevicePoll(WGPUDevice,WGPUBool,const WGPUWrappedSubmissionIndex*);
namespace voxy::physics { WGPUQuerySet radixProfileQuerySet = nullptr; }
using namespace voxy;
struct alignas(16) Pose { glm::vec4 p{0,0,0.5,1}; glm::vec4 q{0,0,0,1}; };
struct alignas(16) Shape { glm::vec4 d{.1,.1,.1,0}; glm::vec4 p{}; glm::vec4 m{-1,-1,-1,1}; };
struct Args { uint32_t indices,instances,first; int32_t base; uint32_t firstInstance; };
using Clock=std::chrono::steady_clock;
double pct(std::vector<double> v,double q) { std::sort(v.begin(),v.end()); return v[std::min(v.size()-1,size_t(std::ceil(q*v.size()))-1)]; }
void check(bool b) { if(!b) { std::cerr<<"oracle/resource failure\n"; std::exit(2); } }
std::vector<std::byte> read(gpu::Context& ctx,WGPUBuffer b,size_t n,const WGPUWrappedSubmissionIndex& si) {
 struct State {bool done=false,ok=false;} state;
 wgpuBufferMapAsync(b,WGPUMapMode_Read,0,n,[](WGPUBufferMapAsyncStatus s,void* p){auto& r=*static_cast<State*>(p);r.ok=s==WGPUBufferMapAsyncStatus_Success;r.done=true;},&state);
 while(!state.done) wgpuDevicePoll(ctx.getDevice(),true,&si);
 check(state.ok);std::vector<std::byte> out(n);const void* p=wgpuBufferGetConstMappedRange(b,0,n);check(p);std::memcpy(out.data(),p,n);wgpuBufferUnmap(b);return out;
}
int main(int argc,char** argv) {
 const uint32_t n=argc>1?uint32_t(std::stoul(argv[1])):262144;
 const uint32_t frames=argc>2?uint32_t(std::stoul(argv[2])):200;
 const bool profile=argc>3?std::stoi(argv[3])!=0:true;
 const char* shader=argc>4?argv[4]:"shaders/physics_deterministic_primitives.wgsl";
 check(n>0&&n<=1048576&&frames>0);
 gpu::Context ctx;gpu::ContextConfig cfg;cfg.enableValidation=false;cfg.enableTimestamps=profile;check(ctx.initHeadless(cfg));
 std::vector<physics::GpuKeyValue> records(n);
 uint32_t rng=123456789;for(uint32_t i=0;i<n;++i){rng^=rng<<13;rng^=rng>>17;rng^=rng<<5;records[i]={rng%65536,(rng>>16)%32768,i,i};if(i%31==0)records[i].keyLow=records[i].keyHigh=0xffffffff;}
 auto golden=records;std::stable_sort(golden.begin(),golden.end(),[](auto a,auto b){return std::tie(a.keyHigh,a.keyLow)<std::tie(b.keyHigh,b.keyLow);});
 auto in=gpu::createBufferWithData(ctx.getDevice(),ctx.getQueue(),gpu::BufferDesc::storage(size_t(n)*16,false,"probe_input"),std::span<const physics::GpuKeyValue>(records));
 auto out=gpu::createBuffer(ctx.getDevice(),gpu::BufferDesc::storage(size_t(n)*16,false,"probe_output"));check(in&&out);
 physics::DeterministicGpuPrimitives primitives;physics::DeterministicGpuPrimitives::Config pc;pc.capacity=n;pc.workgroupSize=256;pc.shaderPath=shader;check(primitives.initialize(ctx.getDevice(),ctx.getQueue(),pc));
 WGPUBuffer resolve=nullptr,timingRead=nullptr;
 if(profile){WGPUQuerySetDescriptor d{};d.type=WGPUQueryType_Timestamp;d.count=48;physics::radixProfileQuerySet=wgpuDeviceCreateQuerySet(ctx.getDevice(),&d);check(physics::radixProfileQuerySet);resolve=gpu::createBuffer(ctx.getDevice(),{.label="probe_resolve",.size=384,.usage=WGPUBufferUsage_QueryResolve|WGPUBufferUsage_CopySrc});timingRead=gpu::createBuffer(ctx.getDevice(),{.label="probe_timing",.size=384,.usage=WGPUBufferUsage_CopyDst|WGPUBufferUsage_MapRead});check(resolve&&timingRead);}
 std::vector<double> times;times.reserve(frames);std::array<std::vector<double>,3> stages;for(auto& s:stages)s.reserve(frames);
 uint64_t hash=14695981039346656037ull;
 for(uint32_t f=0;f<frames+20;++f){
  auto start=Clock::now();WGPUCommandEncoderDescriptor ed{};auto enc=wgpuDeviceCreateCommandEncoder(ctx.getDevice(),&ed);check(primitives.encodeRadixSort(enc,in,out,n,2));
  if(profile){wgpuCommandEncoderResolveQuerySet(enc,physics::radixProfileQuerySet,0,48,resolve,0);wgpuCommandEncoderCopyBufferToBuffer(enc,resolve,0,timingRead,0,384);}
  WGPUCommandBufferDescriptor cd{};auto cmd=wgpuCommandEncoderFinish(enc,&cd);check(cmd);WGPUWrappedSubmissionIndex si{ctx.getQueue(),wgpuQueueSubmitForIndex(ctx.getQueue(),1,&cmd)};wgpuDevicePoll(ctx.getDevice(),true,&si);
  const double elapsed=std::chrono::duration<double,std::milli>(Clock::now()-start).count();if(f>=20)times.push_back(elapsed);
  if(profile){auto bytes=read(ctx,timingRead,384,si);std::array<uint64_t,48> ts;std::memcpy(ts.data(),bytes.data(),384);if(f>=20)for(size_t j=0;j<3;++j){double total=0;for(size_t k=0;k<8;++k)total+=double(ts[k*6+2*j+1]-ts[k*6+2*j])*10.019e-6;stages[j].push_back(total);}}
  wgpuCommandBufferRelease(cmd);wgpuCommandEncoderRelease(enc);
  if(f==19||f==frames+19){size_t bytes=size_t(n)*16;auto rb=gpu::createBuffer(ctx.getDevice(),{.label="probe_oracle",.size=bytes,.usage=WGPUBufferUsage_MapRead|WGPUBufferUsage_CopyDst});check(rb);enc=wgpuDeviceCreateCommandEncoder(ctx.getDevice(),&ed);wgpuCommandEncoderCopyBufferToBuffer(enc,out,0,rb,0,bytes);cmd=wgpuCommandEncoderFinish(enc,&cd);si={ctx.getQueue(),wgpuQueueSubmitForIndex(ctx.getQueue(),1,&cmd)};auto data=read(ctx,rb,bytes,si);check(std::memcmp(data.data(),golden.data(),bytes)==0);if(f==19)for(auto b:data){hash^=std::to_integer<uint8_t>(b);hash*=1099511628211ull;}wgpuBufferDestroy(rb);wgpuBufferRelease(rb);wgpuCommandBufferRelease(cmd);wgpuCommandEncoderRelease(enc);}
 }
 rusage usage{};getrusage(RUSAGE_SELF,&usage);std::cout<<"radix count="<<n<<" frames="<<frames<<" profile="<<profile<<" p50_ms="<<pct(times,.5)<<" p95_ms="<<pct(times,.95)<<" p99_ms="<<pct(times,.99)<<" sorts_per_s="<<1000*frames/std::accumulate(times.begin(),times.end(),0.)<<" rss_kib="<<usage.ru_maxrss<<" golden_hash="<<std::hex<<hash<<std::dec<<"\n";
 const char* names[]={"histogram","prefix","scatter"};if(profile)for(size_t j=0;j<3;++j)std::cout<<"stage="<<names[j]<<" p50_ms="<<pct(stages[j],.5)<<" p95_ms="<<pct(stages[j],.95)<<" p99_ms="<<pct(stages[j],.99)<<"\n";
 primitives.shutdown();for(auto b:{in,out,resolve,timingRead})if(b){wgpuBufferDestroy(b);wgpuBufferRelease(b);}if(physics::radixProfileQuerySet)wgpuQuerySetRelease(physics::radixProfileQuerySet);
}
