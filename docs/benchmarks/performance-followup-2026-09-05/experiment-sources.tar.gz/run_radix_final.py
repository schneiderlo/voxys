import os,subprocess,json
from pathlib import Path
root=Path('/tmp/voxys-perf-followup');rows=[]
for count,capacity in [(100,100),(100,262144),(8192,8192),(8193,8193),(10000,10000),(10000,262144),(262144,262144),(1048576,1048576)]:
 for repeat in range(3):
  for version in (['original','candidate'] if repeat%2==0 else ['candidate','original']):
   env=os.environ|{'VOXY_RADIX_RECORDS':str(count),'VOXY_RADIX_CAPACITY':str(capacity),'VOXY_RADIX_FRAMES':'300'}
   p=subprocess.run(['/usr/bin/time','-v',str(root/version/'gpu_radix_static')],cwd=root/version,env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
   name=f'radix-final-{count}-{capacity}-{version}-{repeat}.log';(root/name).write_text(p.stdout)
   row={'records':count,'capacity':capacity,'version':version,'repeat':repeat,'exit_code':p.returncode,'log':name,'summary':next((l for l in p.stdout.splitlines() if l.startswith('gpu_radix ')),None)}
   rows.append(row);(root/'radix-final.json').write_text(json.dumps(rows,indent=2));print(row,flush=True)
   if p.returncode:raise SystemExit(p.returncode)
