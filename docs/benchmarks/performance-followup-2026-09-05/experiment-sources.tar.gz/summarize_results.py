import json,re,statistics,collections
from pathlib import Path
root=Path('/tmp/voxys-perf-followup')
result={}
for filename,keys in [('replication-final.json',['bodies','layout','version']),('gpu-final.json',['bodies','frames','version']),('radix-final.json',['records','capacity','version']),('gpu-ab.json',['bodies','version']),('gpu-confirm.json',['bodies','version']),('radix-ab.json',['records','capacity','version']),('replication-ab.json',['bodies','layout','version'])]:
 groups=collections.defaultdict(list)
 for row in json.loads((root/filename).read_text()):
  metrics={}
  for token in row['summary'].split()[1:]:
   key,value=token.split('=',1)
   try: metrics[key]=float(value)
   except ValueError: metrics[key]=value
  log=(root/row['log']).read_text();rss=re.search(r'Maximum resident set size \(kbytes\): (\d+)',log)
  if rss:metrics['peak_rss_kib']=int(rss[1])
  groups[tuple(row[k] for k in keys)].append(metrics)
 rows=[]
 for group,values in groups.items():
  row=dict(zip(keys,group));row['repeats']=len(values)
  row['median_of_run_summaries']={k:statistics.median(v[k] for v in values) if isinstance(values[0][k],(int,float)) else values[0][k] for k in values[0]}
  rows.append(row)
 result[filename]=rows
result['aggregation']='Median of per-run p50/p95/p99/throughput/RSS; not pooled percentiles. Quantiles use nearest rank. No run discarded.'
(root/'summary.json').write_text(json.dumps(result,indent=2)+'\n')
for source,rows in result.items():
 if not isinstance(rows,list):continue
 print(source)
 for r in rows:print(r)
