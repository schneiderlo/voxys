from pathlib import Path
import hashlib,json,re,shutil,subprocess
root=Path('/home/lschneid/workspace/schneiderlo/voxys');raw=Path('/mnt/c/Users/m3ndag/AppData/Local/Temp/voxys-startup-two-hours-20260925')
built=Path('/tmp/voxys-two-hour-wasm-bin/voxy_wasm');before=raw/'site-render-baseline';site=raw/'site-final-candidate'
assert (root/'shaders/physics_narrow_phase.wgsl').read_bytes()==(raw/'narrow-combined.wgsl').read_bytes()
if site.exists():raise RuntimeError('Refusing to replace final candidate site')
shutil.copytree(raw/'site-render-candidate',site)
for suffix in ['wasm','data']:shutil.copy2(built/('voxy_wasm_cc.'+suffix),site/('voxy_wasm.'+suffix))
(site/'voxy_wasm.js').write_text((built/'voxy_wasm_cc.js').read_text().replace('voxy_wasm_cc','voxy_wasm'))
shutil.copy2(root/'web/gpu_startup.js',site/'gpu_startup.js')
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert digest(before/'voxy_wasm.wasm')==digest(site/'voxy_wasm.wasm'),'Unexpected engine-code change'
def entries(folder):
 js=(folder/'voxy_wasm.js').read_text();data=(folder/'voxy_wasm.data').read_bytes();rows={}
 for name,start,end in re.findall(r'\{filename:("(?:[^"\\]|\\.)*"),start:(\d+),end:(\d+)\}',js):
  name=json.loads(name);start,end=int(start),int(end);assert name not in rows;rows[name]={'start':start,'end':end,'sha256':hashlib.sha256(data[start:end]).hexdigest()}
 assert len(rows)>100 and min(x['start'] for x in rows.values())==0 and max(x['end'] for x in rows.values())==len(data)
 spans=sorted((x['start'],x['end']) for x in rows.values());assert all(a[1]==b[0] for a,b in zip(spans,spans[1:]))
 return rows,data
old,_=entries(before);new,newdata=entries(site);assert old.keys()==new.keys()
changed=[name for name in old if old[name]['sha256']!=new[name]['sha256']]
assert changed==['/shaders/physics_narrow_phase.wgsl'],changed
row=new[changed[0]];assert newdata[row['start']:row['end']]==(raw/'narrow-combined.wgsl').read_bytes()
index=site/'index.html';html=index.read_text();html,count=re.subn(r"(window\.voxyReleaseFiles = ')[^']+(';)",r'\1__VOXY_RELEASE_FILES__\2',html);assert count==1;index.write_text(html)
subprocess.run(['python3','scripts/write_release_manifest.py',str(site),'--max-core-mib','160'],cwd=root,check=True)
# Experimental release derivation: only the hardware narrow source changed in
# the pack. CI's compatibility source and every captured interface are unchanged.
# Retain the same CI costs/order to isolate the source and warmup changes.
# The normal release workflow captures a fresh recipe for each real release.
capture=json.loads((raw/'software-capture.json').read_text())
capture['release']=digest(site/'voxy_wasm.wasm')+':'+digest(site/'voxy_wasm.data')
for row in capture['resources']:
 if row['kind']!='createShaderModule':continue
 desc=row['descriptor'];label=desc.get('label','');p=root/'shaders'/label
 if label=='physics_narrow_phase.wgsl':assert desc['code']==(root/'shaders/physics_narrow_phase_compat.wgsl').read_text()
 elif p.is_file():assert desc['code']==p.read_text(),label
fixture=raw/'final-derived-software-capture.json';fixture.write_text(json.dumps(capture,separators=(',',':')))
subprocess.run(['python3','scripts/publish_graphics_recipe.py',str(site),str(fixture)],cwd=root,check=True)
record={'site':str(site),'wasm_unchanged':True,'preload_entry_count':len(new),'changed_preload_entries':changed,'changed_preload_bytes':len(newdata)-(before/'voxy_wasm.data').stat().st_size,'recipe_derivation':'Same prior CI software capture and measured costs; release identity updated only after verifying identical WASM and every preload entry except the hardware narrow shader. Every captured file-backed source still matches this release or its unchanged compatibility source.','files':{name:{'sha256':digest(site/name),'size':(site/name).stat().st_size} for name in ['voxy_wasm.wasm','voxy_wasm.js','voxy_wasm.data','gpu_startup.js','voxy_graphics.json','index.html']}}
(raw/'final-candidate-package.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record,indent=2))
