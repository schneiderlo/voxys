from pathlib import Path
import hashlib,json,re,shutil,subprocess
root=Path('/home/lschneid/workspace/schneiderlo/voxys');raw=Path('/mnt/c/Users/m3ndag/AppData/Local/Temp/voxys-startup-two-hours-20260925');old=raw/'site-final-candidate';site=raw/'site-retained-candidate'
if not site.exists():shutil.copytree(old,site)
assert not (raw/'retained-candidate-package.json').exists()
for name in ['voxy_wasm.data','voxy_wasm.js','index.html']:(site/name).chmod(0o644)
shader=(raw/'narrow-final.wgsl').read_bytes();assert shader==(root/'shaders/physics_narrow_phase.wgsl').read_bytes()
pattern=r'\{filename:("(?:[^"\\]|\\.)*"),start:(\d+),end:(\d+)\}'
js=(old/'voxy_wasm.js').read_text();rows=[(json.loads(n),int(s),int(e)) for n,s,e in re.findall(pattern,js)]
target='/shaders/physics_narrow_phase.wgsl';name,start,end=next(row for row in rows if row[0]==target)
olddata=(old/'voxy_wasm.data').read_bytes();assert olddata[start:end]==(raw/'narrow-combined.wgsl').read_bytes();delta=len(shader)-(end-start)
newdata=olddata[:start]+shader+olddata[end:];(site/'voxy_wasm.data').write_bytes(newdata)
def relocate(m):
 name=json.loads(m[1]);s,e=int(m[2]),int(m[3])
 if name==target:e+=delta
 elif s>=end:s+=delta;e+=delta
 else:assert e<=start
 return '{filename:'+m[1]+',start:'+str(s)+',end:'+str(e)+'}'
js=re.sub(pattern,relocate,js);js,count=re.subn(r'remote_package_size:\d+','remote_package_size:'+str(len(newdata)),js);assert count==1;(site/'voxy_wasm.js').write_text(js)
newrows=[(json.loads(n),int(s),int(e)) for n,s,e in re.findall(pattern,js)];assert len(newrows)==len(rows)==321
for (n,s,e),(nn,ss,ee) in zip(rows,newrows):
 assert n==nn
 assert newdata[ss:ee]==(shader if n==target else olddata[s:e]),n
assert max(e for _,_,e in newrows)==len(newdata)
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
index=site/'index.html';html=(old/'index.html').read_text();m=re.search(r"(window\.voxyReleaseFiles = ')([^']+)(';)",html);manifest=json.loads(m[2]);manifest['voxy_wasm.data']={'size':len(newdata),'sha256':digest(site/'voxy_wasm.data')};manifest.pop('voxy_graphics.json',None);index.write_text(html[:m.start(2)]+json.dumps(manifest,separators=(',',':'))+html[m.end(2):])
capture=json.loads((raw/'software-capture.json').read_text());capture['release']=digest(site/'voxy_wasm.wasm')+':'+digest(site/'voxy_wasm.data');p=raw/'retained-derived-software-capture.json';p.write_text(json.dumps(capture,separators=(',',':')))
subprocess.run(['python3','scripts/publish_graphics_recipe.py',str(site),str(p)],cwd=root,check=True)
record={'site':str(site),'method':'Repack the runtime-loaded WGSL entry in the verified WASM build; relocate all generated preload offsets and package size, verify every entry byte-for-byte, regenerate manifest and public recipe.','wasm_unchanged':digest(site/'voxy_wasm.wasm')==digest(raw/'site-render-baseline/voxy_wasm.wasm'),'preload_entry_count':321,'changed_preload_entries':[target],'change_from_original_bytes':len(shader)-len((raw/'narrow-before.wgsl').read_bytes()),'discarded_experiment':'Authored face clipping merge; primitive clipping, authored round ordering and cylinder specialization retained.','files':{name:{'sha256':digest(site/name),'size':(site/name).stat().st_size} for name in ['index.html','voxy_wasm.wasm','voxy_wasm.data','voxy_wasm.js','voxy_graphics.json','gpu_startup.js']}}
assert record['wasm_unchanged'];(raw/'retained-candidate-package.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record,indent=2))
