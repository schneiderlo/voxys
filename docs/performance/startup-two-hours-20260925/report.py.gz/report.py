from pathlib import Path
import gzip,hashlib,json,shutil
raw=Path('/mnt/c/Users/m3ndag/AppData/Local/Temp/voxys-startup-two-hours-20260925')
out=Path('/home/lschneid/workspace/schneiderlo/voxys/docs/performance/startup-two-hours-20260925')
out.mkdir(exist_ok=True)
def canonical(recipe,replace=None):
 def decode(value,constants=False):
  if isinstance(value,list):return [decode(item,constants) for item in value]
  if not isinstance(value,dict):
   return replace[1] if replace and value==replace[0] else value
  if '$gpu' in value:
   row=recipe['resources'][value['$gpu']];return {'kind':row['kind'],'descriptor':decode(row['descriptor'])}
  return {key:decode(item,key=='constants') for key,item in sorted(value.items()) if key!='label' or constants}
 return sorted(json.dumps({'kind':row['kind'],'descriptor':decode(row['descriptor'])},sort_keys=True,separators=(',',':')) for row in recipe['pipelines'])
def archive(path,name):
 (out/(name+'.gz')).write_bytes(gzip.compress(path.read_bytes(),mtime=0))
summary={'goal_start_utc':'2026-09-25 18:44:16 UTC','goal_deadline_utc':'2026-09-25 20:44:16 UTC','measurement':'Local Windows Chrome153, Intel Iris Xe, 1280x720. Fresh profiles unless return visit specified. Normal watchdog; no driver-cache reset. No build or other benchmark during performance sampling.','runs':[],'runtime':[],'native':[]}
basepath=raw/'page-render-before-1/graphics-recipe.json'
base=canonical(json.loads(basepath.read_text())) if basepath.exists() else None
replacement=((raw/'narrow-before.wgsl').read_text(),(raw/'narrow-final.wgsl').read_text())
for folder in sorted(raw.glob('page-*')):
 if not folder.is_dir():continue
 for name in ['report.json','startup.json','graphics-recipe.json','console.log','chrome.log']:
  if (folder/name).exists():archive(folder/name,folder.name+'-'+name)
 p=folder/'report.json'
 if not p.exists():continue
 d=json.loads(p.read_text());record={key:d.get(key) for key in ['complete','device','width','height','instrumented','settleSeconds','graphicsCache','downloads','error']};record['tag']=folder.name
 record['startup']={k:d.get('startup',{}).get(k) for k in ['playable_observed_ms','graphics_span_ms','browser']}
 recipe=folder/'graphics-recipe.json'
 if recipe.exists():
  programs=canonical(json.loads(recipe.read_text()));record['program_count']=len(programs);record['program_sha256']=hashlib.sha256('\n'.join(programs).encode()).hexdigest();record['programs_equal_original']=programs==base
  record['programs_equal_expected_shader_change']=programs==canonical(json.loads(basepath.read_text()),replacement)
  record['programs_equal_experimental_shader_change']=programs==canonical(json.loads(basepath.read_text()),(replacement[0],(raw/'narrow-combined.wgsl').read_text()))
 record['scenarios']=[{'name':s['name'],'elapsedMs':s['elapsedMs'],'rendered_fps':1000*s['summary']['renderedFrames']/s['elapsedMs'],'summary':s['summary'],'health':s['health'],'canvas':s['canvas'],'physics_steps':s['after'].get('physicsFrame') if isinstance(s['after'],dict) else None} for s in d['scenarios']]
 summary['runs'].append(record)
for folder in sorted(raw.glob('runtime-*')):
 if not folder.is_dir():continue
 p=folder/'report.json'
 if p.exists():
  archive(p,folder.name+'-report.json');d=json.loads(p.read_text());summary['runtime'].append({'tag':folder.name,**{k:v for k,v in d.items() if k!='kernels'},'kernels':[{k:v for k,v in row.items() if k!='samples'} for row in d.get('kernels',[])]})
for pattern in ['native-*.log','native-*.xml','*package.json','*jobs.json','native-*.json']:
 for p in raw.glob(pattern):archive(p,p.name)
for name in ['native-checks.json','native-recheck.json','native-final-repeat.json']:
 p=raw/name
 if p.exists():
  d=json.loads(p.read_text());summary['native'].extend(d if isinstance(d,list) else [d])
p=raw/'retained-jobs.json'
if p.exists():summary['native'].extend(row for row in json.loads(p.read_text()) if row['tag'].startswith('native-'))
summary['retained_source_sha256']=hashlib.sha256((raw/'narrow-final.wgsl').read_bytes()).hexdigest()
summary['discarded_experiment']='Authored face-clipping merge: runtime benefit was inconsistent. page-final-* after runs use that earlier experimental source; page-retained-* after runs use the retained source.'
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({'runs':[(r['tag'],r['complete'],r['startup']['playable_observed_ms']) for r in summary['runs']],'runtime_runs':len(summary['runtime']),'native_results':len(summary['native'])}))
