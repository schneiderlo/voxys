	.type	_ZNSt3__26vectorIN4voxy6render12_GLOBAL__N_115GpuDrawInstanceENS_9allocatorIS4_EEE12emplace_backIJRNS2_16MeshDrawInstanceERjEEERS4_DpOT_,@function # -- Begin function _ZNSt3__26vectorIN4voxy6render12_GLOBAL__N_115GpuDrawInstanceENS_9allocatorIS4_EEE12emplace_backIJRNS2_16MeshDrawInstanceERjEEERS4_DpOT_
_ZNSt3__26vectorIN4voxy6render12_GLOBAL__N_115GpuDrawInstanceENS_9allocatorIS4_EEE12emplace_backIJRNS2_16MeshDrawInstanceERjEEERS4_DpOT_: # @_ZNSt3__26vectorIN4voxy6render12_GLOBAL__N_115GpuDrawInstanceENS_9allocatorIS4_EEE12emplace_backIJRNS2_16MeshDrawInstanceERjEEERS4_DpOT_
	.functype	_ZNSt3__26vectorIN4voxy6render12_GLOBAL__N_115GpuDrawInstanceENS_9allocatorIS4_EEE12emplace_backIJRNS2_16MeshDrawInstanceERjEEERS4_DpOT_ (i32, i32, i32) -> ()
	.local  	i32, i32, i32, f32, i32, i32, i32, i32
# %bb.0:
	block   	
	local.get	0
	i32.load	4
	local.tee	3
	local.get	0
	i32.load	8
	local.tee	4
	i32.ge_u
	br_if   	0                               # 0: down to label518
# %bb.1:
	local.get	2
	i32.load	0
	local.set	5
	local.get	3
	local.get	1
	i64.load	64:p2align=2
	i64.store	56
	local.get	3
	local.get	1
	i64.load	56:p2align=2
	i64.store	48
	local.get	3
	local.get	1
	i64.load	48:p2align=2
	i64.store	40
	local.get	3
	local.get	1
	i64.load	40:p2align=2
	i64.store	32
	local.get	3
	local.get	1
	i64.load	32:p2align=2
	i64.store	24
	local.get	3
	local.get	1
	i64.load	24:p2align=2
	i64.store	16
	local.get	3
	local.get	1
	i64.load	16:p2align=2
	i64.store	8
	local.get	3
	local.get	1
	i64.load	8:p2align=2
	i64.store	0
	local.get	3
	local.get	1
	i64.load	80:p2align=2
	i64.store	72
	local.get	3
	local.get	1
	i64.load	72:p2align=2
	i64.store	64
	local.get	1
	f32.load	88
	local.set	6
	local.get	3
	local.get	5
	i32.store	84
	local.get	3
	local.get	6
	f32.store	80
	local.get	3
	local.get	1
	i32.load	104
	i32.store	88
	local.get	3
	local.get	1
	i32.load	108
	i32.store	92
	local.get	3
	local.get	1
	i64.load	116:p2align=2
	i64.store	96
	local.get	3
	local.get	1
	i64.load	124:p2align=2
	i64.store	104
	local.get	3
	local.get	1
	i64.load	132:p2align=2
	i64.store	112
	local.get	3
	local.get	1
	i64.load	140:p2align=2
	i64.store	120
	local.get	0
	local.get	3
	i32.const	128
	i32.add 
	i32.store	4
	return
