	.type	_ZNSt3__26vectorIN4voxy6render12_GLOBAL__N_115GpuDrawInstanceENS_9allocatorIS4_EEE9push_backB8ne210108ERKS4_,@function # -- Begin function _ZNSt3__26vectorIN4voxy6render12_GLOBAL__N_115GpuDrawInstanceENS_9allocatorIS4_EEE9push_backB8ne210108ERKS4_
_ZNSt3__26vectorIN4voxy6render12_GLOBAL__N_115GpuDrawInstanceENS_9allocatorIS4_EEE9push_backB8ne210108ERKS4_: # @_ZNSt3__26vectorIN4voxy6render12_GLOBAL__N_115GpuDrawInstanceENS_9allocatorIS4_EEE9push_backB8ne210108ERKS4_
	.functype	_ZNSt3__26vectorIN4voxy6render12_GLOBAL__N_115GpuDrawInstanceENS_9allocatorIS4_EEE9push_backB8ne210108ERKS4_ (i32, i32) -> ()
	.local  	i32, i32, i32, i32, i32, i32, i32
# %bb.0:
	block   	
	local.get	0
	i32.load	4
	local.tee	2
	local.get	0
	i32.load	8
	local.tee	3
	i32.ge_u
	br_if   	0                               # 0: down to label322
# %bb.1:
	local.get	2
	local.get	1
	i32.const	128
	memory.copy	0, 0
	local.get	0
	local.get	2
	i32.const	128
	i32.add 
	i32.store	4
	return
